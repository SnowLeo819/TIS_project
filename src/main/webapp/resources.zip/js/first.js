// alert("hello javascript");
console.log("hello javascript")
